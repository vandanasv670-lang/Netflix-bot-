# Netflix-bot-
A chat bot that suggests Netflix shows and movies by genre actor or mood
